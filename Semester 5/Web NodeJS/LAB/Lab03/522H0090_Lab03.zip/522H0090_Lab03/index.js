const express = require("express")
const bodyParser = require("body-parser")
const session = require("express-session")
require('dotenv').config();
const PORT = process.env.PORT || 8080;
const app = express()

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: false }))


app.get('/', (req, res) => {
    let products = [
        { id: 1, name: "iPhone 12 Pro", price: 30000000 },
        { id: 2, name: "iPhone 11", price: 17000000 },
        { id: 3, name: "iPhone Xr", price: 11000000 },
    ]
    res.render('home', { products });
})

//views/login.ejs
app.get('/login', (req, res) => {
    res.render('login')

})

app.get('/products', (req, res) => {
    let products = [
        { id: 1, name: "iPhone 12 Pro", price: 30000000 },
        { id: 2, name: "iPhone 11", price: 17000000 },
        { id: 3, name: "iPhone Xr", price: 11000000 },
    ]
    res.render('products', { products });
})


app.post('/login', (req, res) => {
    let { email, password } = req.body
    console.log(email, password);
    
})

app.listen(PORT, () => {
    console.log(`http://localhost:${PORT}`);
})







