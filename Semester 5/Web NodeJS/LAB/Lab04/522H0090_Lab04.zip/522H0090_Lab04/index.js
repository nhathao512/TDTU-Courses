const express = require("express")
const bodyParser = require("body-parser")
const session = require("express-session")
require('dotenv').config();
const PORT = process.env.PORT || 8080;
const app = express()
const multer = require('multer')
const upload = multer({ dest: 'uploads' })

const products = [
    { id: 1, name: "iPhone 12 Pro", price: 30000000 },
    { id: 2, name: "iPhone 11", price: 17000000 },
    { id: 3, name: "iPhone Xr", price: 11000000 },
]

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads')
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now()
        cb(null, file.fieldname + '-' + uniqueSuffix + '-' + file.originalname)
    }
})

app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}))

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: false }))

app.use('/uploads', express.static('uploads'))

app.get('/', (req, res) => {
    let { user } = req.session
    if (!user) return res.redirect('/login')
    res.render('home', { products });
})

//views/login.ejs
app.get('/login', (req, res) => {
    res.render('login')

})

app.post('/login', (req, res) => {
    let { email, password } = req.body
    let error = ''
    const admin_email = process.env.ADMIN_EMAIL
    const admin_pass = process.env.ADMIN_PASSWORD

    if (email != admin_email)
        error = "Sai email"
    if (password != admin_pass)
        error = "Sai password"


    if (error.length > 0) {
        res.render('login', {
            errorMessage: error
        })
    }
    else {
        req.session.user = {
            admin_email
        }
        return res.redirect('/')
    }

})

app.get('/products', (req, res) => {

    res.render('products', { products });
})

app.get('/add', (req, res) => {
    res.render('add');
})

app.post('/add', upload.single('product_img'), (req, res) => {
    let { product_name, product_pice, product_desc } = req.body
    let image = req.file;
    console.log(product_name, product_pice, image, product_desc,);
    products.push({ id: undefined, name: product_name, price: product_pice, image: image.filename, desc: product_desc })
    return res.render('/')
})


app.listen(PORT, () => {
    console.log(`http://localhost:${PORT}`);
})







